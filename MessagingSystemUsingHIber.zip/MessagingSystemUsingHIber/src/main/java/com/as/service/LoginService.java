package com.as.service;

public interface LoginService {

    public boolean checkLogin(String username, String password);

}

