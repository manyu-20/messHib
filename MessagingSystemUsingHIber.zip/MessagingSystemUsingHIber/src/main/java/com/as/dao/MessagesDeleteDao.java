package com.as.dao;

public interface MessagesDeleteDao {
	boolean deleteMessage(int pk);
}
