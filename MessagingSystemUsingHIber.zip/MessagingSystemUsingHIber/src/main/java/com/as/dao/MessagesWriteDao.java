package com.as.dao;

import com.as.model.MessagesOld;

public interface MessagesWriteDao {
	MessagesOld insert(MessagesOld message);
}
